package main

import (
	"github.com/mathewmoon/tfdoc-html/cmd"
)

func main() {
	cmd.Execute()
}
